import { defineConfig } from 'vite'
import AdmZip from 'adm-zip'
import react from '@vitejs/plugin-react'

export default defineConfig({
  base: '/react-ui/',
  plugins: [react(), {
      name: 'zip-dist', // zipping ./dist is required for BTP HTML5 repo or Application Frontend deployment
      closeBundle() {
        const zip = new AdmZip()
        zip.addLocalFolder('dist')
        zip.writeZip('dist/react-ui.zip')
      }
  }],
  server: {
    proxy: {
      '/odata': 'http://localhost:4004',
      '/api': 'http://localhost:4004',
      '/nomination-eta-service': 'http://localhost:4004'
    }
  }
})
